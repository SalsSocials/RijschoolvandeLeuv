import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import logoAsset from "@/assets/logo-vandeleuv.png.asset.json";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Rijschool Van De Leuv | Autorijles West-Friesland" },
      { name: "description", content: "Autorijschool in Hoorn, Enkhuizen en heel West-Friesland. Persoonlijke rijles bij Joey van de Leuv. Veilig, zelfverzekerd en met plezier je rijbewijs halen." },
      { name: "theme-color", content: "#0A6BFF" },
      { property: "og:title", content: "Rijschool Van De Leuv | Autorijles West-Friesland" },
      { property: "og:description", content: "Autorijschool in Hoorn, Enkhuizen en heel West-Friesland. Persoonlijke rijles bij Joey van de Leuv. Veilig, zelfverzekerd en met plezier je rijbewijs halen." },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Rijschool Van De Leuv" },
      { property: "og:locale", content: "nl_NL" },
      { name: "twitter:card", content: "summary" },
      { name: "twitter:title", content: "Rijschool Van De Leuv | Autorijles West-Friesland" },
      { name: "twitter:description", content: "Autorijschool in Hoorn, Enkhuizen en heel West-Friesland. Persoonlijke rijles bij Joey van de Leuv. Veilig, zelfverzekerd en met plezier je rijbewijs halen." },
      { property: "og:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/lyiXxtjwdvhmNALudhce4A7oYit2/social-images/social-1780594310077-WhatsApp_Image_2026-05-28_at_17.20.02.webp" },
      { name: "twitter:image", content: "https://storage.googleapis.com/gpt-engineer-file-uploads/lyiXxtjwdvhmNALudhce4A7oYit2/social-images/social-1780594310077-WhatsApp_Image_2026-05-28_at_17.20.02.webp" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap",
      },
      { rel: "icon", type: "image/png", href: logoAsset.url },
      { rel: "apple-touch-icon", href: logoAsset.url },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "DrivingSchool",
          name: "Rijschool Van De Leuv",
          description:
            "Persoonlijke autorijschool in West-Friesland. Rijles in Hoorn, Enkhuizen, Bovenkarspel, Grootebroek, Hoogkarspel, Venhuizen, Andijk, Wervershoof en omliggende plaatsen.",
          areaServed: [
            "Hoorn","Enkhuizen","Bovenkarspel","Grootebroek","Hoogkarspel",
            "Venhuizen","Hem","Andijk","Wervershoof","Blokker","Zwaag",
            "Oosterblokker","Westwoud","Schellinkhout","West-Friesland",
          ],
          address: {
            "@type": "PostalAddress",
            addressRegion: "Noord-Holland",
            addressCountry: "NL",
            addressLocality: "Hoorn",
          },
          founder: {
            "@type": "Person",
            name: "Joey van de Leuv",
            jobTitle: "Rijinstructeur",
            description:
              "Rijinstructeur met zeven jaar ervaring. Vier jaar bij Van Vught en drie jaar bij Rijschool West-Friesland.",
          },
          priceRange: "€€",
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: "4.9",
            reviewCount: "120",
          },
        }),
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
    </QueryClientProvider>
  );
}
